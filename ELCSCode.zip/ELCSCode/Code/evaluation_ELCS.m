function [mean_F1] = evaluation_ELCS(data,truePC,trueP,trueC,alpha,dataset)

    [n,p] = size(data{1});
    mean_precision1 = [];
    mean_recall1 = [];
    mean_distance1 = [];
    mean_F11 = [];

    mean_test1 = [];
    mean_time1 = [];
    mean_undirected1 = [];
    mean_reverse1 = [];
    mean_miss1 = [];
    mean_extra1 = [];
    mean_total1 = [];

    all_PC=cell(10,p);
    FDR = [];
    Arrhd_precision = [];
    Arrhd_recall = [];
    k = 3;
    for j = 1:10
        ns = max(data{j});
        data{j}=data{j}-1;
        precision = [];
        recall = [];
        F1 = [];
        distance = [];
        test = [];
        time = [];
        undirected = [];
        reverse = [];
        miss = [];
        extra = [];
        total = [];
        %----my add------%
        fdr_tmp = [];
        arr_precision = [];
        arr_recall = [];
        for i = 1:p
            [PC,P,C,UN,ntest,ntime] = ELCS(data{j}, ns,i, alpha,p,k);
            all_PC{j,i}=PC;
            test = [test ntest];
            time = [time,ntime];

            [pre,rec,dis,F1val] = eva_PC(PC,truePC{i});
            precision = [precision pre];
            recall = [recall rec];
            distance = [distance dis];
            F1 = [F1 F1val];

            G=zeros(p,p); DAG=zeros(p,p);
            G(i,trueC{i})=-1;   G(trueP{i},i)=-1;
            DAG(i,C)=-1;        DAG(P,i)=-1;
            if length(UN) > 0
                DAG(i,UN)=1;        DAG(UN,i)=1;
            end

            [arr_precision_tmp,arr_recall_tmp,arr_distance_tmp,arr_F1_tmp] = eva_ArrhdPR(trueC{i},C,trueP{i},P);
            arr_precision = [arr_precision,arr_precision_tmp];
            arr_recall = [arr_recall,arr_recall_tmp];

            [nundirected,nreverse,nmiss,nextra,ntotal] = eva_LCSError(G,DAG);
            fdr_tmp = [fdr_tmp, Compute_FDR(nreverse,trueC{i},C,trueP{i},P,UN,i,p)];
            undirected = [undirected,nundirected];
            reverse = [reverse,nreverse];
            miss = [miss,nmiss];
            extra = [extra,nextra];
            total = [total,ntotal];      
        end

        mean_time1 = [mean_time1 mean(time)];
        mean_test1 = [mean_test1 mean(test)];
        mean_precision1 = [mean_precision1 mean(precision)];
        mean_recall1 = [mean_recall1 mean(recall)];
        mean_distance1 = [mean_distance1 mean(distance)];
        mean_F11 = [mean_F11 mean(F1)];

        mean_undirected1 = [mean_undirected1,mean(undirected)];
        mean_reverse1 = [mean_reverse1,mean(reverse)];
        mean_miss1 = [mean_miss1,mean(miss)];
        mean_extra1 = [mean_extra1,mean(extra)];
        mean_total1 = [mean_total1,mean(total)];
        FDR = [FDR, mean(fdr_tmp)];
        Arrhd_precision = [Arrhd_precision, mean(arr_precision)];
        Arrhd_recall = [Arrhd_recall, mean(arr_recall)];
    end

    std_time = std(mean_time1);
    std_test = std(mean_test1);
    std_precision = std(mean_precision1);
    std_recall = std(mean_recall1);
    std_distance = std(mean_distance1);
    std_F1 = std(mean_F11);

    mean_time = mean(mean_time1);
    mean_test = mean(mean_test1);
    mean_precision = mean(mean_precision1);
    mean_recall = mean(mean_recall1);
    mean_distance = mean(mean_distance1);
    mean_F1 = mean(mean_F11);


    std_undirected = std(mean_undirected1);
    std_reverse = std(mean_reverse1);
    std_miss = std(mean_miss1);
    std_extra = std(mean_extra1);
    std_total = std(mean_total1);

    mean_undirected = mean(mean_undirected1);
    mean_reverse = mean(mean_reverse1);
    mean_miss = mean(mean_miss1);
    mean_extra = mean(mean_extra1);
    mean_total = mean(mean_total1);


    std_FDR  = std(FDR);
    mean_FDR = mean(FDR);
    std_arrhd_precision  = std(Arrhd_precision);
    mean_arrhd_precision = mean(Arrhd_precision);
    std_arrhd_recall  = std(Arrhd_recall);
    mean_arrhd_recall = mean(Arrhd_recall);


%     fprintf('\n%.2f+%.2f\n',mean_F1,std_F1);
%     fprintf('%.2f+%.2f\n',mean_distance,std_distance);
%     fprintf('%.2f+%.2f\n',mean_precision,std_precision);
%     fprintf('%.2f+%.2f\n',mean_recall,std_recall);
    

   
    fprintf('ArrP:       %.2f+%.2f\n',mean_arrhd_precision,std_arrhd_precision);
    fprintf('ArrR:       %.2f+%.2f\n',mean_arrhd_recall,std_arrhd_recall);
    fprintf('SHD:        %.2f+%.2f\n',mean_total,std_total);
%     fprintf('undirected: %.2f+%.2f\n',mean_undirected,std_undirected);
%     fprintf('reverse:    %.2f+%.2f\n',mean_reverse,std_reverse);
%     fprintf('miss:       %.2f+%.2f\n',mean_miss,std_miss);
%     fprintf('extra:      %.2f+%.2f\n',mean_extra,std_extra);
    fprintf('FDR:        %.2f+%.2f\n',mean_FDR,std_FDR);
    fprintf('CI Tests:   %.0f+%.0f\n',mean_test,std_test);
    fprintf('Time:       %.2f+%.2f\n\n',mean_time,std_time);

%     fid=fopen('ELCS_Result.txt','at');
%     fprintf(fid,'%s_%s\n\nF1\ndistance\nprecision\nrecall\ntest\ntime\n\n',dataset,num2str(n));
%     fprintf(fid,'%.2f+%.2f\n%.2f+%.2f\n',mean_F1,std_F1,mean_distance,std_distance);
%     fprintf(fid,'%.2f+%.2f\n%.2f+%.2f\n%.0f+%.0f\n%.2f+%.2f\n\n',mean_precision,std_precision,mean_recall,std_recall,mean_test,std_test,mean_time,std_time);
% 
% 
%     fprintf(fid,'\nFDR\n%.2f+%.2f\n',mean_FDR,std_FDR);
%     fprintf(fid,'\nArrhd_precision\n%.2f+%.2f\n',mean_arrhd_precision,std_arrhd_precision);
%     fprintf(fid,'\nArrhd_recall\n%.2f+%.2f\n',mean_arrhd_recall,std_arrhd_recall);
%     fprintf(fid,'\ntotal\nundirected\nreverse\nmiss\nextra\n\n%.2f+%.2f\n',mean_total,std_total);
%     fprintf(fid,'%.2f+%.2f\n%.2f+%.2f\n%.2f+%.2f\n%.2f+%.2f\n\n',mean_undirected,std_undirected,mean_reverse,std_reverse,mean_miss,std_miss,mean_extra,std_extra);
%     fclose(fid);
end

