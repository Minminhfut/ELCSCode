
function [precision,recall,distance,F1]=eva_PC(PC,truePC)



if isempty(truePC)
    if isempty(PC)
        precision=1;
        recall=1;
        distance=0;
        F1=1;
    elseif ~isempty(PC)
        precision=0;
        recall=0;
        distance=sqrt(2);
        F1=0;
    end
elseif ~isempty(truePC)
    if ~isempty(PC)
        precision1=length(intersect(PC,truePC))/length(PC);
        recall1=length(intersect(PC,truePC))/length(truePC);
        distance1=sqrt((1-recall1)*(1-recall1)+(1-precision1)*(1-precision1));
        if (precision1+recall1)==0
            f1=0;
        else
            f1=2*precision1*recall1/(precision1+recall1);
        end
        precision=precision1;
        recall=recall1;
        distance=distance1;
        F1=f1;
    else
        precision=0;
        recall=0;
        distance=sqrt(2);
        F1=0;
    end
end

